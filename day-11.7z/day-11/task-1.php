<?php


  
    if(isset($_GET["submit"]))
    {
        if(isset($_GET["no1"])&&isset($_GET["no2"])){
            $no1 = $_GET["no1"];
            $no2 = $_GET["no2"];
            $res = $no1 + $no2;
        }
    }
?>

<!DOCTYPE html>
<html>
<body>

<form action="#"  method="get">
  <input type="number" name="no1" ><br>
  <br>
  <input type="number" name="no2"><br><br>
  <button name="submit">submit</button>
  <br>
  <br>

<input type="radio" id="html" name="fav_language" value="HTML">
<label for="html">HTML</label><br>
<input type="radio" id="css" name="fav_language" value="CSS">
<label for="css">CSS</label><br>
<input type="radio" id="javascript" name="fav_language" value="JavaScript">
<label for="javascript">JavaScript</label>
<br>
<br>

  <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike">
  <label for="vehicle1"> I have a bike</label><br>
  <input type="checkbox" id="vehicle2" name="vehicle2" value="Car">
  <label for="vehicle2"> I have a car</label><br>
  <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
  <label for="vehicle3"> I have a boat</label>
  <br>
  <br>
  <label for="cars">Choose a car:</label>

<select id="cars">
  <option value="volvo">Volvo</option>
  <option value="BMW">BMW</option>
  <option value="Defender">DEFENDER</option>
  <option value="audi">Audi</option>
</select>
<br>
<br>
  <input type="number" name="ans" value="<?php echo $res;?>">
</form> 
</body>
</html>